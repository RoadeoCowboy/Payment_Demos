<!DOCTYPE html>
<html>
<title>Amazon</title>
<head>

</head>

<body>
<a href=".\flash_sale.html">Flash Sale</a>
<a href=".\fee_calculator.php">Fee Calculator</a>
</body>

</html>